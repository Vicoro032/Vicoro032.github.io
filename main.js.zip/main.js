function trigger()
{
    document.getElementById("hover").addEventListener("click", popup);
}

function popup()
{
    alert("Quack!!!");
}